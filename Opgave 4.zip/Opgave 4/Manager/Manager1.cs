﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Opgave_4.Manager;
using FootballplayerObject;

namespace Opgave_4.Manager
{
    public class Manager1 : Imanager
    {
        public static List<FootballPlayer> Player = new List<FootballPlayer>()
        {
            new FootballPlayer(1, "Messi", 100, 10),
            new FootballPlayer(2, "Neymar", 500, 5),
            new FootballPlayer(3, "Patrick", 1000, 1),
        };

        public bool Create(FootballPlayer value)
        {
            int NextId = Player.Count();
            value.ID = NextId;
            Player.Add(value);

            return true;
        }

        public FootballPlayer Delete(int id)
        {
            FootballPlayer player = Get(id);
            Player.Remove(player);
            return player;
        }

        public IEnumerable<FootballPlayer> Get()
        {
            return new List<FootballPlayer>(Player);
        }
        public FootballPlayer Get(int id)
        {
            return Player.Find(i => i.ID == id);
        }

        public bool Update(int id, FootballPlayer value)
        {
            FootballPlayer player = Get(id);
            if (player != null)
            {
                player.ID = value.ID;
                player.Name = value.Name;
                player.Price = value.Price;
                player.ShirtNumber = value.ShirtNumber;
                return true;
            }
            return false;
        }

    }


}
