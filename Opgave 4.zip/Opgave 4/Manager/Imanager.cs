﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FootballplayerObject;

namespace Opgave_4.Manager
{
    interface Imanager
    {
        IEnumerable<FootballPlayer> Get();
        FootballPlayer Get(int id);
        bool Create(FootballPlayer value);
        FootballPlayer Delete(int id);
        bool Update(int id, FootballPlayer value);
        
    }
}
